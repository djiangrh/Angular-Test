export interface ILoginResult {
    loginSuccessful: boolean;
}
