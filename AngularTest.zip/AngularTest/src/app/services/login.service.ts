import { Injectable } from '@angular/core';
import { ILoginResult } from '../login/ilogin-result';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }

  login(username: string, password: string): Promise<ILoginResult> {
  
    let loginreturn: ILoginResult = { loginSuccessful: true };

   

    let loginResult = new Promise<ILoginResult>((resolve, reject) => {
      if (username && password) {
        loginreturn.loginSuccessful = true;
        resolve(loginreturn);
      } else {
        loginreturn.loginSuccessful = false;
        reject(loginreturn);
      }
      
    });
    return loginResult;


  }

}
